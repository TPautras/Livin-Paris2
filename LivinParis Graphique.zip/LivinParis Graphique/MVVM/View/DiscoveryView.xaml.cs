﻿using System.Windows.Controls;

namespace LivinParis_Graphique.MVVM.View
{
    public partial class DiscoveryView : UserControl
    {
        public DiscoveryView()
        {
            InitializeComponent();
        }
    }
}