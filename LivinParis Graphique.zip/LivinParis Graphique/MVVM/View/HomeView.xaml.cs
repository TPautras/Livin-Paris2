﻿using System.Windows.Controls;

namespace LivinParis_Graphique.MVVM.View
{
    public partial class HomeView : UserControl
    {
        public HomeView()
        {
            InitializeComponent();
        }
    }
}