﻿namespace LivinParis_Graphique.MVVM.ViewModel
{
    public class DiscoveryViewModel
    {
        
    }
}