﻿using LivinParis_Graphique.Core;

namespace LivinParis_Graphique.MVVM.ViewModel
{
    public class HomeViewModel : ObservableObject
    {
        public HomeViewModel()
        {
            
        }
    }
}